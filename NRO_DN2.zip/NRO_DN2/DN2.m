clc; clear; close all;
fid = fopen('vozlisca_temperature_dn2_6.txt','r');

fgetl(fid);

Nx = sscanf(fgetl(fid), '%*[^:]: %d');
Ny = sscanf(fgetl(fid), '%*[^:]: %d');
Nt = sscanf(fgetl(fid), '%*[^:]: %d');
fclose(fid);
data = readmatrix('vozlisca_temperature_dn2_6.txt', 'NumHeaderLines',4 );

x = data(:,1);
y = data(:,2);
T = data(:,3);

xt=0.403;
yt=0.503;

%% 
%ScatteredInterpolant
tic
F = scatteredInterpolant(x, y, T, 'linear', 'none');
T_scatter = F(xt,yt);
t_scatter=toc;

%% 


% GriddledInterpolant

xv=unique(x);
yv=unique(y);


[~, ix] = ismember(x, xv);  
[~, iy] = ismember(y, yv);   



Tgrid = NaN(Nx, Ny);
ind = sub2ind([Nx, Ny], ix, iy);
Tgrid(ind) = T;              

tic
F = griddedInterpolant({xv, yv}, Tgrid, 'linear');   

T_gridded = F(xt,yt);
t_gridded=toc;

%%

fid = fopen('celice_dn2_6.txt','r');

fgetl(fid);

Nc = sscanf(fgetl(fid), '%*[^:]: %d');

cells = readmatrix('celice_dn2_6.txt', 'NumHeaderLines', 2);

tic
for i = 1:Nc
    % Iteriramo čez vse celice

    % cell_points vsebuje seznam z: [ ID vozlišča 1, 2, 3 in 4]
    cell_points = cells(i,:); 

    cell_point1 = cell_points(1); % ID vozlišča 1
    cell_point2 = cell_points(2); % ID vozlišča 2
    cell_point3 = cell_points(3); % ID vozlišča 3
    cell_point4 = cell_points(4); % ID vozlišča 4

    x11 = x(cell_point1); % x-koordinata vozlišča 1
    x21 = x(cell_point2); % x-koordinata vozlišča 2
    x22 = x(cell_point3); % x-koordinata vozlišča 3
    x12 = x(cell_point4); % x-koordinata vozlišča 4

    y11 = y(cell_point1); % y-koordinata vozlišča 1
    y21 = y(cell_point2); % y-koordinata vozlišča 2
    y22 = y(cell_point3); % y-koordinata vozlišča 3
    y12 = y(cell_point4); % y-koordinata vozlišča 4

    t11 = T(cell_point1); % t-koordinata vozlišča 1
    t21 = T(cell_point2); % t-koordinata vozlišča 2
    t22 = T(cell_point3); % t-koordinata vozlišča 3
    t12 = T(cell_point4); % t-koordinata vozlišča 4

      % Določitev meja celice
    xmin = min([x11 x21 x12 x22]);
    xmax = max([x11 x21 x12 x22]);
    ymin = min([y11 y21 y12 y22]);
    ymax = max([y11 y21 y12 y22]);
    
    
    if xt >= xmin && xt <= xmax && yt >= ymin && yt <= ymax
        
        % Bilinearna interpolacija
        K1 = (xmax-xt)/(xmax-xmin)*t11 + (xt-xmin)/(xmax-xmin)*t21;
        K2 = (xmax-xt)/(xmax-xmin)*t12 + (xt-xmin)/(xmax-xmin)*t22;
        T_bilinear = (ymax-yt)/(ymax-ymin)*K1 + (yt-ymin)/(ymax-ymin)*K2
        
        found = true;
        break; % zelo pomembno: takoj nehaj!
    end
   

end

t_bi=toc

%%
disp('T_bilinear ='); disp(T_bilinear);
disp('T_gridded ='); disp(T_gridded);
disp('T_scatter ='); disp(T_scatter);

disp('t_bi ='); disp(t_bi);
disp('t_gridded ='); disp(t_gridded);
disp('t_scatter ='); disp(t_scatter);

%vsi načini računanja so prišli do istega rezultata.
%scatteredInterpolant je dalec najpocasnejsi, Bilinearno je počasnejše od
% griddedInterpolant.
 
%%

[maxT, idx_max] = max(T);
maxX = x(idx_max);
maxY = y(idx_max);

fprintf('Največja temperatura: %.6f °C pri koordinatah (%.6f, %.6f)\n', maxT, maxX, maxY);
